<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Employee_controller extends CI_Controller{

    public function __construct()
    {
        parent::__construct();   
        $this->load->model('Employee_model','EModel');
        $this->load->library('form_validation');
        $this->load->helper('file');
    }
    public function index()
    {
        // echo "vk";
        $result=$this->EModel->get_employees();
        if(isset($result)&& !empty($result))
        {
            $data['employee_data']=$result;
        }
        else{
            $data['employee_data']="";
        }
        $this->load->view('employee_management',$data);
    }
    public function import()
    {
        if($this->input->post('importSubmit')){
            $this->form_validation->set_rules('file', 'CSV file', 'callback_file_check');
            if($this->form_validation->run() == true){
                
                $count=0;
                $csvfile=fopen($_FILES['file']['tmp_name'],'r') or die("can't open file");
                $fp = file($_FILES['file']['tmp_name']);
                if(count($fp) <= 21)
                {
                    while($csv_line=fgetcsv($csvfile,1024))
                    {
                        $count ++;
                        if($count==1)
                        {
                            $this->session->set_flashdata('error','No emplyees found on this file.');
                            continue;
                        }
                        if(count($csv_line)>=5)
                        {
                            for($i=0;$i < count($csv_line);$i++)
                            {
                                $dob = new DateTime($csv_line[3]);
                                $today   = new DateTime('today');
                                $datetime1 = new DateTime($csv_line[4]);
                                $interval = $datetime1->diff($today);
                                $insert_csv = array();
                                $insert_csv['Emp_Code'] = $csv_line[0];
                                $insert_csv['Emp_Name'] = $csv_line[1];
                                $insert_csv['Department'] = $csv_line[2];
                                $insert_csv['Age'] = $dob->diff($today)->y;
                                $insert_csv['Experience'] =  $interval->format('%y years %m months');
                                $empdata=array(
                                    'Emp_Code'=>$insert_csv['Emp_Code'],
                                    'Emp_Name'=>$insert_csv['Emp_Name'],
                                    'Department'=>$insert_csv['Department'],
                                    'Age'=>$insert_csv['Age'],
                                    'Experience'=>$insert_csv['Experience']
                                );
                                $checkexist=$this->EModel->getrows($insert_csv['Emp_Code']);
                                if($checkexist > 0)
                                {
                                    $result=$this->EModel->update_employees($empdata,$insert_csv['Emp_Code']);
                                }else{
                                    $result=$this->EModel->add_employees($empdata);
                                }

                            }
                            $this->session->set_flashdata('success','Employee added successfully.');
                        } 
                        else{
                            $this->session->set_flashdata('error','Employee data should be more than 5 coloums.');
                        }
                    }
                    fclose($csvfile) or die("can't close file");
                }   
                else{
                    $this->session->set_flashdata('error','Employee count should be less than 20.');
                } 
              
            }else{
                $this->session->set_flashdata('error', 'Please select a CSV file to upload.');
            }
           
        }
        redirect('employee');
    }
    public function file_check($str)
    {
        $allowed_mime_types = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
        if(isset($_FILES['file']['name']) && $_FILES['file']['name'] != ""){
            $mime = get_mime_by_extension($_FILES['file']['name']);
            $fileAr = explode('.', $_FILES['file']['name']);
            $ext = end($fileAr);
            if(($ext == 'csv') && in_array($mime, $allowed_mime_types)){
                return true;
            }else{
                $this->form_validation->set_message('file_check', 'Please select only CSV file to upload.');
                return false;
            }
        }else{
            $this->form_validation->set_message('file_check', 'Please select a CSV file to upload.');
            return false;
        }
    }

}
?>