<?php
class Employee_model extends CI_Model{
    public function __construct()
    {
        parent::__construct();
        // $this->db->cache_on();
        $this->load->database();
    }
    public function get_employees()
    {
        $this->db->select('*');
        $this->db->from('employees');
        $result=$this->db->get()->result();
        return $result;

    }
    public function add_employees($data)
    {
        if(isset($data) && !empty($data))
        {
            $result=$this->db->insert('employees',$data);
            if($this->db->insert_id()>0)
            {
                return $this->db->insert_id();
            }else{
                return false;
            }
        }
    }
    public function update_employees($data,$empcode)
    {
        if(isset($data) && !empty($data))
        {
            $this->db->where('Emp_Code',$empcode);
            $result=$this->db->update('employees',$data);
            if($this->db->affected_rows()>0)
            {
                return $this->db->affected_rows();
            }else{
                return false;
            }
        }
    }
    public function getrows($empcode)
    {
        $this->db->where('Emp_Code',$empcode);
        $this->db->from('employees');
        $result=$this->db->get()->num_rows();
        return $result;
    } 
}
?>