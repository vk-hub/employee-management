<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Employee Management</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="container">
            <?php if($this->session->flashdata('success'))
            {?>
            <div class="col-xs-12">
                <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
            </div>
            <?php }
               else if($this->session->flashdata('error'))
            {?>
            <div class="col-xs-12">
                <div class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></div>
            </div>
            <?php }?>
           
            <div class="row justify-content-center" style="padding:10px;">
                <div class="col-md-12" id="importFrm" >
                    <form action="<?php echo base_url();?>employee/import" method="post" enctype="multipart/form-data">
                        <input type="file" name="file" />
                        <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
                    </form>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row justify-content-center" style="padding:10px;">

                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <th>Employee Code</th>
                        <th>Employee Name</th>
                        <th>Department</th>
                        <th>Age</th>
                        <th>Experience</th>
                    </thead>
                    <tbody>
                        <?php if(isset($employee_data) && !empty($employee_data))
                        {
                            foreach($employee_data as $employee)
                            {?>
                                <tr>
                                    <td><?php echo $employee->Emp_Code;?></td>
                                    <td><?php echo $employee->Emp_Name;?></td>
                                    <td><?php echo $employee->Department;?></td>
                                    <td><?php echo $employee->Age;?></td>
                                    <td><?php echo $employee->Experience;?></td>
                                </tr>
                            <?php }
                        }
                        else{?>
                            <tr>
                               <td colspan=5 align ="center">No data found</td>
                            </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
<script>
    $("document").ready(function(){
    setTimeout(function(){
        $("div.alert").remove();
    }, 5000 ); // 5 secs

});
</script>