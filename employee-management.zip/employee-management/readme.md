php 7.3
codeigniter 3.1
xampp server
ide:visual studio code
database :mysql

csv file import to mysql database and check already exist with employee